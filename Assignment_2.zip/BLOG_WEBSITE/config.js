// config.js
module.exports = {
    mongoURI: 'mongodb+srv://sultanshahid2425:sultanshahid2425@cluster0.fvfxh.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0' // Adjust this if using a cloud service
};
